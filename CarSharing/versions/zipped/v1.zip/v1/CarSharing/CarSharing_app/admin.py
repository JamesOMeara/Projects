from django.contrib import admin

# Register your models here.

from CarSharing_app.models import CarSharingData
admin.site.register(CarSharingData)
