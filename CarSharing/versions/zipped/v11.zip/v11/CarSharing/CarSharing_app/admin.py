from django.contrib import admin

# Register your models here.

from CarSharing_app.models import route

admin.site.register(route)
